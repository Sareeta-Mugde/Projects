


from __future__ import unicode_literals, print_function
import pandas as pd

def find_all(a_str, sub):
    start = 0
    while True:
        start = a_str.find(sub, start)
        if start == -1: return
        yield start
        start += len(sub) # use start += 1 to find overlapping matches




def createNerAnnotationForEachWord(text,word,label):
    fd=[]
    fd=find_all(text,word)
    st=""
    for t in fd:
        st=st+ "(\"" +text+"\",{\"entities\": [("+str(t)+","+str(t+len(word))+",\""+label+"\")]},),"
        
    return(st)
  
 

LABEL=[]

def load_data_train():
    df=pd.read_csv("/home/siddhesh/workarea/sareeta/Final SRC/NER MODEL TRAINING AND TESTING/nercsv.csv")
    global LABEL 
    TRAIN_DATA="["
    for index, row in df.iterrows():
        salist=createNerAnnotationForEachWord(row['sentence'].lower(), row['word'].lower(),row['label'].upper())
        TRAIN_DATA=TRAIN_DATA+salist
        LABEL.append(row['label'].upper())
        
    TRAIN_DATA=TRAIN_DATA[:-3]+"),]"

    print(TRAIN_DATA)
    return(str(TRAIN_DATA))


load_data_train()