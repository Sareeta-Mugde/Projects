

import os
import io
import os
from os import getcwd, listdir
import glob, os
import shutil
import subprocess
count=0


def get_doc_text(filepath, file,root):
    #dest1 is the path to store the file after converting it to text
    dest1 = '/home/siddhesh/workarea/sareeta/TESTINGFOLDER/patientdocx'
    global count
    if filepath.endswith('.doc'):
  
       doc_file = filepath 
       docx_file = filepath +'x'
       text_f=file.partition(".doc")
       text_file=root+text_f[0]+".txt"
   
       if not os.path.exists(text_file):
    
            text_file='/home/siddhesh/workarea/sareeta/TESTINGFOLDER/patientdocx/'+text_f[0]+".txt"
            subprocess.call(['soffice', '--headless', '--convert-to', 'txt','--outdir', '/home/siddhesh/workarea/sareeta/TESTINGFOLDER/patientdocx/', doc_file])


            #IF YOU WANT TO COVERT DOCX THEN USE THE CODE BELOW

            #subprocess.call(['soffice', '--headless', '--convert-to', 'docx','--outdir', '/home/siddhesh/workarea/sareeta/TESTINGFOLDER/patientdocx/', docx_file])
            #name =docx_file.rsplit('.',1)[0]
            #ext = docx_file.rsplit('.',1)[1]
            #os.system("mv docx_file file2")
            #shutil.move(docx_file, dest1)
            #pdelete="/home/siddhesh/workarea/sareeta/TESTINGFOLDER/patientdocx/"+text_file
            #os.remove(pdelete)
            
            
#This is the Path where is the original data of ODR reports is stored             
filepath = '/home/siddhesh/workarea/projects/drbhat/PatientData'
countp=0
countdocx=0
counttotal = 0

destdocx = '/home/siddhesh/workarea/sareeta/TESTINGFOLDER/patientdocx'
destpdf='/home/siddhesh/workarea/sareeta/TESTINGFOLDER/patientpdf'

try:
    for root, dirs, files in os.walk("/home/siddhesh/workarea/projects/drbhat/PatientData"):
        try:

            for file in files:
                filename =os.path.join(root, file)
                #print(filename)
                get_doc_text(filename,file,root)

                if filename.endswith('x'):
                    #print(filename)
                    countdocx=countdocx+1
                    shutil.copy2(filename, destdocx)
                if filename.endswith('pdf'):
                    #print(filename)
                    countp=countp+1
                    shutil.copy2(filename, destpdf)  
                counttotal = countp + countdocx + count
                print(counttotal)
        except Exception as e:
            print()
            continue
    print (counttotal)
          
 
except Exception as e:
    print("a")
    
    
# except e:
#     print("Error in opening file", e)


