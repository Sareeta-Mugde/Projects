

import os
import pandas
import numpy as np
import csv
import re

try:
    from StringIO import StringIO
except ImportError:
    from io import StringIO


count=0


class SplitFile:
    def getalldetails(self,filename):    
        #read the entire file as text
        text=""

        with open(filename, 'rb') as f:
            source_stream = StringIO(str(f.read()))    
            text = source_stream.getvalue()


        if(text=="b''"): return 

        
        text=text.lower()
        text=text.strip()


        text=text.replace("\n","")
        text=text.replace("\\n","")
        text=text.replace("[pic]","")
        text=text.replace("|","")
        text=text.rstrip("\n")


        text=' '.join(text.split())


        textnew=list(text.partition("impression"))

        textbeforeimpression=textnew[0]

        
        textnew=textnew[2].strip()
        textnew=textnew.replace("\n","")
        textnew=textnew.replace(":","")
        textnew2=list(textnew.partition(r"("))
        impressiontext=textnew2[0]
       
        textbeforescan=list(textbeforeimpression.partition(r"scan"))

        textafterscan=textbeforescan[2]
        textbeforescan=textbeforescan[0]
        endposition=re.compile(r'(\d{4})').search(textafterscan).end()

        endposition=len(textbeforescan)+endposition+4

        reportinfo=textbeforeimpression[:endposition]
        testandobs=textbeforeimpression[endposition+1:]



        partitionTO=testandobs.split(".")

        testname=partitionTO[0]

        observations=partitionTO[1:]


        print("ORIGINAL TEXT \t"+text)
        print("\n\n")
        print("REPORTINFO  "+reportinfo)
        print("\n\n")
        print("TESTNAME  "+testname)
        print("\n\n")
        print("OBSERVATIONS  ")
        print(observations)
        print("\n\n")
        print("IMPRESSION "+impressiontext)
        output=[]
        d={}
        if(text):
            text=text
        else:
            text=""
        if(reportinfo):
            reportinfo=reportinfo
        else:
            reportinfo=""
        if(testname):
            testname=testname
        else:
            testname=""
        if(observations):
            observations=observations
        else:
            observations=""
        if(impressiontext):
            impressiontext=impressiontext
        else:
            impressiontext=""





        d['document'] = text

        d['reportinfo'] = reportinfo
        d['testname'] = testname
        d['observations'] = observations
        d['impression'] = impressiontext

        #print(d)
        return (d)


    
    def getreportinfo(self,filename):    
        #read the entire file as text
        text=""


        with open(filename, 'rb') as f:
            source_stream = StringIO(str(f.read()))
#             print(source_stream)
            text = source_stream.getvalue()


        if(text=="b''"): return 

      
        text=text.lower()
        text=text.strip()


        text=text.replace("\n","")
        text=text.replace("\\n","")
        text=text.replace("|","")
        text=text.replace("[pic]","")
        text=text.rstrip("\n")


        text=' '.join(text.split())

        textnew=list(text.partition("impression"))

        textbeforeimpression=textnew[0]

       
        textnew=textnew[2].strip()
        textnew=textnew.replace("\n","")
        textnew=textnew.replace(":","")
        textnew2=list(textnew.partition(r"("))
        impressiontext=textnew2[0]
        #print("\n\n")
        #print(textbeforeimpression)
        textbeforescan=list(textbeforeimpression.partition(r"scan"))

        textafterscan=textbeforescan[2]
        textbeforescan=textbeforescan[0]
        endposition=re.compile(r'(\d{4})').search(textafterscan).end()

        endposition=len(textbeforescan)+endposition+4

        reportinfo=textbeforeimpression[:endposition]
        testandobs=textbeforeimpression[endposition+1:]



        partitionTO=testandobs.split(".")

        testname=partitionTO[0]

        observations=partitionTO[1:]


        output=[]
    
        if(text):
            text=text
        else:
            text=""
        if(reportinfo):
            reportinfo=reportinfo
        else:
            reportinfo=""
        if(testname):
            testname=testname
        else:
            testname=""
        if(observations):
            observations=observations
        else:
            observations=""
        if(impressiontext):
            impressiontext=impressiontext
        else:
            impressiontext=""


        return (reportinfo)
    
    
    
    def getobservations(self,filename):    
        #read the entire file as text
        text=""


        with open(filename, 'rb') as f:
            source_stream = StringIO(str(f.read()))
            print(source_stream)
            text = source_stream.getvalue()


        if(text=="b''"): return 

        text=text.lower()
        text=text.strip()


        text=text.replace("\n","")
        text=text.replace("\\n","")
        text=text.replace("|","")
        text=text.rstrip("\n")
        text=text.replace("[pic]","")


        text=' '.join(text.split())

        textnew=list(text.partition("impression"))

        textbeforeimpression=textnew[0]

        textnew=textnew[2].strip()
        textnew=textnew.replace("\n","")
        textnew=textnew.replace(":","")
        textnew2=list(textnew.partition(r"("))
        impressiontext=textnew2[0]
       
        textbeforescan=list(textbeforeimpression.partition(r"scan"))

        textafterscan=textbeforescan[2]
        textbeforescan=textbeforescan[0]
        endposition=re.compile(r'(\d{4})').search(textafterscan).end()

        endposition=len(textbeforescan)+endposition+4

        reportinfo=textbeforeimpression[:endposition]
        testandobs=textbeforeimpression[endposition+1:]



        partitionTO=testandobs.split(".")

        testname=partitionTO[0]

        observations=partitionTO[1:]



        output=[]
  
        if(text):
            text=text
        else:
            text=""
        if(reportinfo):
            reportinfo=reportinfo
        else:
            reportinfo=""
        if(testname):
            testname=testname
        else:
            testname=""
        if(observations):
            observations=observations
        else:
            observations=""
        if(impressiontext):
            impressiontext=impressiontext
        else:
            impressiontext=""
   
        return (observations)
    
    
    
    def getimpression(self,filename):    
        #read the entire file as text
        text=""

        with open(filename, 'rb') as f:
            source_stream = StringIO(str(f.read()))
#             print(source_stream)
            text = source_stream.getvalue()


        if(text=="b''"): return 

        text=text.lower()
        text=text.strip()


        text=text.replace("\n","")
        text=text.replace("\\n","")
        text=text.replace("|","")
        text=text.rstrip("\n")
        text=text.replace("[pic]","")


        text=' '.join(text.split())

        textnew=list(text.partition("impression"))

        textbeforeimpression=textnew[0]

        textnew=textnew[2].strip()
        textnew=textnew.replace("\n","")
        textnew=textnew.replace(":","")
        textnew2=list(textnew.partition(r"("))
        impressiontext=textnew2[0]
        
        
        partitionI=impressiontext.split(".")

        impressiontext=partitionI
        
        textbeforescan=list(textbeforeimpression.partition(r"scan"))

        textafterscan=textbeforescan[2]
        textbeforescan=textbeforescan[0]
        endposition=re.compile(r'(\d{4})').search(textafterscan).end()

        endposition=len(textbeforescan)+endposition+4

        reportinfo=textbeforeimpression[:endposition]
        testandobs=textbeforeimpression[endposition+1:]



        partitionTO=testandobs.split(".")

        testname=partitionTO[0]

        observations=partitionTO[1:]


        output=[]
       
        if(text):
            text=text
        else:
            text=""
        if(reportinfo):
            reportinfo=reportinfo
        else:
            reportinfo=""
        if(testname):
            testname=testname
        else:
            testname=""
        if(observations):
            observations=observations
        else:
            observations=""
        if(impressiontext):
            impressiontext=impressiontext
        else:
            impressiontext=""

        return (impressiontext)





    def gettestname(self,filename):    
        #read the entire file as text
        text=""


        with open(filename, 'r') as f:
            source_stream = StringIO(str(f.read()))
            text = source_stream.getvalue()


        if(text=="b''"): return 

        text=text.lower()
        text=text.strip()


        text=text.replace("\n","")
        text=text.replace("\\n","")
        text=text.replace("|","")
        text=text.rstrip("\n")
        text=text.replace("[pic]","")


        text=' '.join(text.split())

        textnew=list(text.partition("impression"))

        textbeforeimpression=textnew[0]

        textnew=textnew[2].strip()
        textnew=textnew.replace("\n","")
        textnew=textnew.replace(":","")
        textnew2=list(textnew.partition(r"("))
        impressiontext=textnew2[0]
       
        textbeforescan=list(textbeforeimpression.partition(r"scan"))

        textafterscan=textbeforescan[2]
        textbeforescan=textbeforescan[0]
        endposition=re.compile(r'(\d{4})').search(textafterscan).end()

        endposition=len(textbeforescan)+endposition+4

        reportinfo=textbeforeimpression[:endposition]
        testandobs=textbeforeimpression[endposition+1:]



        partitionTO=testandobs.split(".")

        testname=partitionTO[0]

        observations=partitionTO[1:]

        output=[]
       
        d={}
        if(text):
            text=text
        else:
            text=""
        if(reportinfo):
            reportinfo=reportinfo
        else:
            reportinfo=""
        if(testname):
            testname=testname
        else:
            testname=""
        if(observations):
            observations=observations
        else:
            observations=""
        if(impressiontext):
            impressiontext=impressiontext
        else:
            impressiontext=""

        d['testname'] = testname

        return (testname)

    def getpatientname(self,filename):
        text=self.getreportinfo(filename)
        if "patient" in text:
            nametext=text.partition("patient")
            name=nametext[0]
            name=name.partition(":")
            name=name[2]

            pnotext=nametext[2].partition("referred")
            pno=pnotext[0]
            pno=pno.replace("no","")
            pno=pno.replace(":","")
            pno=pno.replace(" ","")

            reftext=pnotext[2].partition("scan")
            ref=reftext[0]
            ref=ref.replace("by","")
            ref=ref.replace(":","")


            scantext=reftext[2].partition(":")
            scan=scantext[2]
            scan=scan.replace("by","")
            scan=scan.replace(":","")


        if "patient" not in text:
            nametext=text.partition("referred")
            name=nametext[0]
            name=name.partition(":")
            name=name[2]

            reftext=nametext[2].partition("scan")
            ref=reftext[0]
            ref=ref.replace("by","")
            ref=ref.replace(":","")


            scantext=reftext[2].partition(":")
            scan=scantext[2]
            scan=scan.replace("by","")
            scan=scan.replace(":","")
        name=name.replace("\n","")
        print(name)
        return (name)
    
        
        
    def getrefname(self,filename):
        text=self.getreportinfo(filename)
        if "patient" in text:
            nametext=text.partition("patient")
            name=nametext[0]
            name=name.partition(":")
            name=name[2]

            pnotext=nametext[2].partition("referred")
            pno=pnotext[0]
            pno=pno.replace("no","")
            pno=pno.replace(":","")
            pno=pno.replace(" ","")

            reftext=pnotext[2].partition("scan")
            ref=reftext[0]
            ref=ref.replace("by","")
            ref=ref.replace(":","")


            scantext=reftext[2].partition(":")
            scan=scantext[2]
            scan=scan.replace("by","")
            scan=scan.replace(":","")


        if "patient" not in text:
            nametext=text.partition("referred")
            name=nametext[0]
            name=name.partition(":")
            name=name[2]

            reftext=nametext[2].partition("scan")
            ref=reftext[0]
            ref=ref.replace("by","")
            ref=ref.replace(":","")


            scantext=reftext[2].partition(":")
            scan=scantext[2]
            scan=scan.replace("by","")
            scan=scan.replace(":","")
        ref=ref.replace("\n","")
        print(ref)
        return (ref)

        
    def getpatientno(self,filename):
        text=self.getreportinfo(filename)
        if "patient" in text:
            nametext=text.partition("patient")
            name=nametext[0]
            name=name.partition(":")
            name=name[2]

            pnotext=nametext[2].partition("referred")
            pno=pnotext[0]
            pno=pno.replace("no","")
            pno=pno.replace(":","")
            pno=pno.replace(" ","")

            reftext=pnotext[2].partition("scan")
            ref=reftext[0]
            ref=ref.replace("by","")
            ref=ref.replace(":","")


            scantext=reftext[2].partition(":")
            scan=scantext[2]
            scan=scan.replace("by","")
            scan=scan.replace(":","")


        if "patient" not in text:
            nametext=text.partition("referred")
            name=nametext[0]
            name=name.partition(":")
            name=name[2]

            reftext=nametext[2].partition("scan")
            ref=reftext[0]
            ref=ref.replace("by","")
            ref=ref.replace(":","")


            scantext=reftext[2].partition(":")
            scan=scantext[2]
            scan=scan.replace("by","")
            scan=scan.replace(":","")
            pno=""
        pno=pno.replace("\n","")
        print(pno)
        return (pno)

        
    def getscandate(self,filename):
        text=self.getreportinfo(filename)
        if "patient" in text:
            nametext=text.partition("patient")
            name=nametext[0]
            name=name.partition(":")
            name=name[2]

            pnotext=nametext[2].partition("referred")
            pno=pnotext[0]
            pno=pno.replace("no","")
            pno=pno.replace(":","")
            pno=pno.replace(" ","")

            reftext=pnotext[2].partition("scan")
            ref=reftext[0]
            ref=ref.replace("by","")
            ref=ref.replace(":","")


            scantext=reftext[2].partition(":")
            scan=scantext[2]
            scan=scan.replace("by","")
            scan=scan.replace(":","")


        if "patient" not in text:
            nametext=text.partition("referred")
            name=nametext[0]
            name=name.partition(":")
            name=name[2]

            reftext=nametext[2].partition("scan")
            ref=reftext[0]
            ref=ref.replace("by","")
            ref=ref.replace(":","")


            scantext=reftext[2].partition(":")
            scan=scantext[2]
            scan=scan.replace("by","")
            scan=scan.replace(":","")
            
        scan=scan.replace("\n","")
        print(scan)
        return (scan)
     

def main():
    filename = input("Enter File Name ")
    s1= SplitFile()
    flag=True    

    while(flag):    

        while(True):
            print("Options: \n 1)Get All File Info \n 2)Get Report Information \n 3)Get Test name \n 4) Get Observation \n 5)Get Impression\n 6)Exit \n")
            choice=input("Enter your choice ")
            print(choice)
            if(choice=='1'):
                text=s1.getalldetails(filename)
                break

            elif(choice=='2'):
                text=s1.getreportinfo(filename)
                print(text)
                s1.getpatientname(filename)
                s1.getpatientno(filename)
                s1.getrefname(filename)
                s1.getscandate(filename)
                break

            elif(choice=='3'):
                text=s1.gettestname(filename)
                print(text)
                break

            elif(choice=='4'):
                text=s1.getobservations(filename)
                print(text)
                break

            elif(choice=='5'):
                text=s1.getimpression(filename)
                print(text)
                break

            elif(choice=='6'):
                flag=False
                break

            else:
                print("Invalid Choice")
                break
  
if __name__== "__main__":
  main()










